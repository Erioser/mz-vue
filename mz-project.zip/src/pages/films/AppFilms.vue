<template>
    <section class="app-films">
        App-Films
    </section>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" >
    .app-films {

    }
</style>

