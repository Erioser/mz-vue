<template>
    <section class="app-user-info">
      app-user-info
    </section>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" >
    .app-user-info{

    }
</style>

